import os
import torch
import torch.nn as nn
from torchvision import transforms, datasets
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from tqdm import tqdm
from CLIP_PROJECT.clip import clip


class ClipAddLinearModel:
    def __init__(self, clip_model_path: str, classifier_path: str, device: str = None):
        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"
        self.device = device

        # 加载 CLIP 视觉骨干
        self.model, _ = clip.load(clip_model_path, device=device, download_root="../models_clip_vision_backbones")
        self.model.visual.eval()  # 冻结 CLIP 视觉骨干

        # 加载分类器
        self.classifier = torch.load(classifier_path, map_location=device)
        self.classifier.eval()

    def predict(self, images):
        """
        对输入的图像进行预测，返回预测类别。
        """
        with torch.no_grad():
            image_features = self.model.encode_image(images)
            image_features = image_features.float()
            outputs = self.classifier(image_features)
            _, predictions = outputs.max(1)
        return predictions


def evaluate_model(clip_model_name: str, classifier_path: str, test_loader, class_names: list, device: str = None):
    """
    使用指定的 CLIP 模型和分类器对测试集进行评估。
    """
    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"

    # 加载 CLIP 模型和对应的预处理
    clip_model, preprocess = clip.load(clip_model_name, device=device, download_root="../models_clip_vision_backbones")
    clip_model.visual.eval()  # 冻结 CLIP 视觉骨干
    classifier = torch.load(classifier_path, map_location=device)
    classifier.eval()

    y_true = []
    y_pred = []

    # 修改 DataLoader 的 transform 为模型的预处理
    dataset = datasets.ImageFolder(test_data_dir, transform=preprocess)
    test_loader = torch.utils.data.DataLoader(dataset, batch_size=32, shuffle=False, num_workers=4)

    # 对测试数据进行预测
    for images, labels in tqdm(test_loader, desc=f"Evaluating {clip_model_name}"):
        images, labels = images.to(device), labels.to(device)

        with torch.no_grad():
            image_features = clip_model.encode_image(images)
            image_features = image_features.float()
            outputs = classifier(image_features)
            _, predictions = outputs.max(1)

        y_true.extend(labels.cpu().numpy())
        y_pred.extend(predictions.cpu().numpy())

    # 计算评估指标
    accuracy = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, average="weighted", zero_division=0)
    recall = recall_score(y_true, y_pred, average="weighted", zero_division=0)
    f1 = f1_score(y_true, y_pred, average="weighted", zero_division=0)

    return accuracy, precision, recall, f1

if __name__ == "__main__":
    # 定义参数
    test_data_dir = "../dataset/data_brain_tumor_test"  # 测试数据集路径
    class_names = ["glioma_tumor", "meningioma_tumor", "normal", "pituitary_tumor"]
    available_models = ["RN50", "RN101", "RN50x4", "RN50x16", "RN50x64", "ViT-B/32", "ViT-B/16", "ViT-L/14", "ViT-L/14@336px"]

    device = "cuda" if torch.cuda.is_available() else "cpu"
    results = []

    output_file = "metrics_test_clip_vision_only_classifier_on_brain_tumor_test.txt"

    with open(output_file, "w") as file:
        file.write("Model\tAccuracy\tPrecision\tRecall\tF1-score\n")  # 写入文件头

        for model_name in available_models:
            print(f"Evaluating {model_name}...")
            safe_model_name = model_name.replace("/", "_").replace("@", "_")
            classifier_path = f"./{safe_model_name}_classifier.pth"

            # 如果分类器模型存在，则进行评估
            if os.path.exists(classifier_path):
                # 动态加载模型和对应的预处理
                _, preprocess = clip.load(model_name, device="cpu", download_root="../models_clip_vision_backbones")

                # 创建针对当前模型的 DataLoader
                test_dataset = datasets.ImageFolder(test_data_dir, transform=preprocess)
                test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=32, shuffle=False, num_workers=4)

                accuracy, precision, recall, f1 = evaluate_model(
                    clip_model_name=model_name,
                    classifier_path=classifier_path,
                    test_loader=test_loader,
                    class_names=class_names,
                    device=device
                )
                results.append((model_name, accuracy, precision, recall, f1))
                print(f"{model_name}: Accuracy={accuracy:.4f}, Precision={precision:.4f}, Recall={recall:.4f}, F1-score={f1:.4f}")

                # 写入文件
                file.write(f"{model_name}\t{accuracy:.4f}\t{precision:.4f}\t{recall:.4f}\t{f1:.4f}\n")
            else:
                print(f"Classifier model for {model_name} not found. Skipping...")

    print(f"\nMetrics saved to {output_file}")
