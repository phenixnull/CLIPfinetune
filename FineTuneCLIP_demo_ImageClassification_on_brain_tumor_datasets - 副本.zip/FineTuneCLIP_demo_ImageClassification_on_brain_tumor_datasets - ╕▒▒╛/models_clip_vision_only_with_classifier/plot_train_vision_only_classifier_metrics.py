import matplotlib.pyplot as plt
import random

def safe_float(s):
    s = s.strip()
    if s == "":
        return None
    try:
        return float(s)
    except ValueError:
        return None

file_path = "metrics_train_clip_vision_olny_classifier_on_brain_tumor_train.txt"  # 数据文件路径

models_data = {}
highlight_models = {
    "RN50x64": {"color": "blue", "linewidth": 2.5},
    "ViT-L_14_336px": {"color": "red", "linewidth": 2.5},
}
default_colors = ["green", "orange", "purple", "brown", "pink", "gray", "olive"]  # 其他模型随机颜色

if __name__ == "__main__":
    with open(file_path, "r", encoding="utf-8") as f:
        lines = f.readlines()

    current_model = None

    for line in lines:
        line = line.strip()
        if not line:
            continue

        if "Acc" in line:
            # 提取模型名称和Acc数据
            parts = line.split(" Acc ")
            current_model = parts[0].strip()
            acc_values = [safe_float(x) for x in parts[1].split(",")]
            models_data[current_model] = {"acc": acc_values}
        elif "Loss" in line and current_model:
            # 提取Loss数据
            parts = line.split(" Loss ")
            loss_values = [safe_float(x) for x in parts[1].split(",")]
            models_data[current_model]["loss"] = loss_values

    # 开始绘制图表
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))

    # 设置子图标题
    ax1.set_title("Accuracy over 15 Epochs")
    ax2.set_title("Loss over 15 Epochs")

    ax1.set_xlabel("Epoch")
    ax1.set_ylabel("Accuracy")
    ax2.set_xlabel("Epoch")
    ax2.set_ylabel("Loss")

    # 假设每个模型都有15个epoch的数据
    epochs = range(1, 16)

    for model_name, data in models_data.items():
        acc_values = data.get("acc", [])
        loss_values = data.get("loss", [])

        # 检查是否为高亮模型
        if model_name in highlight_models:
            style = highlight_models[model_name]
            color = style["color"]
            linewidth = style["linewidth"]
        else:
            # 随机分配颜色和默认线宽
            color = random.choice(default_colors)
            linewidth = 1.5

        # 绘制Acc曲线
        if len(acc_values) == 15:
            ax1.plot(epochs, acc_values, label=model_name, color=color, linewidth=linewidth, marker='o')
        else:
            print(f"Warning: {model_name} does not have exactly 15 acc values.")

        # 绘制Loss曲线
        if len(loss_values) == 15:
            ax2.plot(epochs, loss_values, label=model_name, color=color, linewidth=linewidth, marker='o')
        else:
            print(f"Warning: {model_name} does not have exactly 15 loss values.")

    ax1.legend()
    ax2.legend()

    # 调整布局
    plt.tight_layout()

    # 保存图表到文件
    plt.savefig("plot_train_clip_vision_olny_classifier_metrics.png", dpi=600)

    # 显示图表
    plt.show()
