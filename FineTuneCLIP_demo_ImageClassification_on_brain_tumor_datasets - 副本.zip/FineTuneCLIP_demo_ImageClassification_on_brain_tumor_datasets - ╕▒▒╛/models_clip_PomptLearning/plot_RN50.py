import matplotlib.pyplot as plt
if __name__ == "__main__":
    # Step 1: Read data from train_loss.txt
    file_path = "train_loss.txt"

    with open(file_path, "r") as file:
        data = file.read()

    # Step 2: Convert the data into a list of floats
    loss_values = [float(value) for value in data.split()]

    # Step 3: Plot the data
    plt.figure(figsize=(10, 6))
    plt.plot(range(1, len(loss_values) + 1), loss_values, label="Text_PromptLearning_Base_RN50_Loss", linewidth=2)

    # Step 4: Customize the plot
    plt.title("Training Loss Curve", fontsize=16)
    plt.xlabel("Epoch", fontsize=14)
    plt.ylabel("Loss", fontsize=14)
    plt.legend(fontsize=12)
    plt.grid(True)
    # 保存图形为png文件
    plt.savefig('PromptLearning_RN50_Loss.png')
    # Step 5: Show the plot
    plt.show()
