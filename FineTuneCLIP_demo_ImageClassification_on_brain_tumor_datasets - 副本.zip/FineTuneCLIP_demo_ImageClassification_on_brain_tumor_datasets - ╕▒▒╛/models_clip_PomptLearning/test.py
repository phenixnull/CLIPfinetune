import os
import torch
from torch.utils.data import DataLoader
from torchvision import datasets, transforms
from tqdm import tqdm
from CLIP_PROJECT.clip import clip
import torch.nn.functional as F
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score
from train import PromptLearningModel
def getDataLoader_clip_model(dataset_path=r"dataset/data_brain_tumor_test", batch_size=1):
    clip_model, clip_preprocess = clip.load("RN50", download_root="../models_clip_vision_backbones")

    # Combine CLIP preprocess steps
    custom_preprocess = transforms.Compose([
        clip_preprocess.transforms[0],  # Resize
        clip_preprocess.transforms[1],  # CenterCrop
        clip_preprocess.transforms[2],  # ToTensor
        clip_preprocess.transforms[3],  # Normalize (CLIP standard)
    ])

    # Load dataset using ImageFolder
    dataset = datasets.ImageFolder(root=dataset_path, transform=custom_preprocess)

    # Generate text labels
    categories = dataset.classes
    dataset.classes = [f"a photo of {category} brain" for category in categories]

    labels_to_texts = {idx: f"a photo of {category} brain" for idx, category in enumerate(categories)}
    # Create DataLoader
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=4)
    return dataset,dataloader, clip_model, labels_to_texts







def evaluate(model, test_loader,test_dataset,labels_to_texts):
    model.eval()
    all_preds = []
    all_labels = []
    classes_num = len(test_dataset.classes)
    classes_features = {label:model.encode_texts(labels_to_texts[label]) for label in labels_to_texts.keys()}
    # Disable gradient computation (as it's not needed during evaluation)
    with torch.no_grad():
        for image, label in tqdm(test_loader, desc="Evaluating"):
            image_features, _ = image.to(model.device), label.to(model.device)

            # Forward pass
            image_features, text_features, label = model(image, label)
            image_features = F.normalize(image_features, dim=1)  # Normalize image features

            # Debug: Check shapes
            # print("image_features shape:", image_features.shape)

            # Convert classes_features to tensor
            class_features_tensor = torch.stack(
                [classes_features[label].reshape(-1) for label in classes_features]
            ).to(model.device)  # Shape: [num_classes, 256]

            # Debug: Check shape
            # print("class_features_tensor shape:", class_features_tensor.shape)

            # Normalize class features
            class_features_tensor = F.normalize(class_features_tensor, dim=1)

            # Compute similarity
            similarity = torch.matmul(image_features, class_features_tensor.T)  # Shape: [1, num_classes]

            # Debug: Check similarity shape
            # print("similarity shape:", similarity.shape)

            # Get the predicted class
            pred = similarity.argmax(dim=1).item()

            # Append predictions and true labels
            all_preds.append(pred)
            all_labels.append(label.item())

    # 计算四个指标
    accuracy = accuracy_score(all_labels, all_preds)
    precision = precision_score(all_labels, all_preds, average='weighted')
    recall = recall_score(all_labels, all_preds, average='weighted')
    f1 = f1_score(all_labels, all_preds, average='weighted')

    # 打印结果
    print(f"Accuracy: {accuracy:.4f}")
    print(f"Precision: {precision:.4f}")
    print(f"Recall: {recall:.4f}")
    print(f"F1-score: {f1:.4f}")

    # 保存到文件
    with open("test_metrics.txt", "w") as f:
        f.write(f"Accuracy: {accuracy:.4f}\n")
        f.write(f"Precision: {precision:.4f}\n")
        f.write(f"Recall: {recall:.4f}\n")
        f.write(f"F1-score: {f1:.4f}\n")


# batch_size只能=1去测试
if __name__ == "__main__":
    test_dataset,test_dataloader, clip_model, labels_to_texts = getDataLoader_clip_model(dataset_path=r"dataset/data_brain_tumor_test")
    device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
    # Load the trained model
    model = PromptLearningModel(clip_model, labels_to_texts).to(device)
    model_path = './models/CTL_RN50.pth'
    model.load_state_dict(torch.load(model_path))
    print(f"Model loaded from {model_path}")


    model.eval()
    evaluate(model,test_dataloader,test_dataset,labels_to_texts)
    # Evaluate the model

