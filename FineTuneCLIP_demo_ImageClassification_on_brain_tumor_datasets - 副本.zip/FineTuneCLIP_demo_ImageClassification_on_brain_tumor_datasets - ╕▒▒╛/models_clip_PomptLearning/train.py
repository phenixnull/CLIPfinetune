import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import datasets, transforms
from tqdm import tqdm
from CLIP_PROJECT.clip import clip
import torch.nn.functional as F
from torch.optim.lr_scheduler import StepLR

class PromptLearningModel(nn.Module):
    def __init__(self, clip_model, labels_to_texts, prompt_length=16):
        super(PromptLearningModel, self).__init__()
        self.device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
        # self.device = "cpu"
        self.clip_model = clip_model
        # Freeze all CLIP parameters
        for parameter in clip_model.parameters():
            parameter.requires_grad = False
        self.clip_model.to(self.device)
        self.clip_model.eval()  # Freeze CLIP model
        self.clip_model_text_max_dim = 77  # Maximum token embedding size
        self.prompt_length = prompt_length
        self.labels_to_texts = labels_to_texts

        # Prompt token initialization
        self.prompt_tokenized = torch.nn.Parameter(torch.randn((self.prompt_length), device=self.device))

        self.text_linear_projection = nn.Linear(self.clip_model_text_max_dim, 61)

        # Define linear layers for projection to 256 dimensions
        self.image_features_projection = nn.Linear(1024, 256)  # Adjust input dim if different
        self.text_features_projection = nn.Linear(77, 256)  # Adjust input dim if different

    def encode_texts(self,texts:list):
        # Tokenize texts and move to device
        self.texts_tokenized = clip.tokenize(texts=texts).to(self.device)

        # Convert tokenized texts to float and move to device
        self.texts_tokenized = self.texts_tokenized.float().to(self.device)

        # Ensure Linear layer is on the correct device
        self.text_linear_projection = self.text_linear_projection.to(self.device)

        # Get batch size and token length
        batch_size, token_length = self.texts_tokenized.shape

        # Apply linear projection
        self.projected_texts_tokenized = self.text_linear_projection(self.texts_tokenized)

        # Expand prompt tokens for each batch
        prompt_expanded = self.prompt_tokenized.unsqueeze(0).expand(batch_size, -1)

        # Concatenate prompt and projected text tokens
        self.texts_tokenized = torch.cat((prompt_expanded, self.projected_texts_tokenized), dim=1)
        # print(self.texts_tokenized.shape,self.texts_tokenized.dtype,self.texts_tokenized[0])
        texts_features=self.texts_tokenized
        texts_features = torch.tensor(texts_features,dtype=torch.float32)
        texts_features = self.text_features_projection(texts_features)
        return texts_features
    def encode_images(self,images):
        images = images.to(self.device)
        images_features = self.clip_model.encode_image(images).to(self.device)
        images_features = torch.tensor(images_features, dtype=torch.float32)
        images_features = self.image_features_projection(images_features)
        return images_features

    def forward(self, images, labels):
        texts = [self.labels_to_texts[label.item()] for label in labels]
        texts_features = self.encode_texts(texts)
        images_features = self.encode_images(images)
        # print(images_features.shape,images_features.dtype)
        # print(texts_features.shape,texts_features.dtype)
        return images_features,texts_features,labels



def getDataLoader_clip_model(dataset_path=r"dataset/data_brain_tumor_train", batch_size=32):
    clip_model, clip_preprocess = clip.load("RN50", download_root="../models_clip_vision_backbones")

    # Combine CLIP preprocess steps
    custom_preprocess = transforms.Compose([
        clip_preprocess.transforms[0],  # Resize
        clip_preprocess.transforms[1],  # CenterCrop
        clip_preprocess.transforms[2],  # ToTensor
        clip_preprocess.transforms[3],  # Normalize (CLIP standard)
    ])

    # Load dataset using ImageFolder
    dataset = datasets.ImageFolder(root=dataset_path, transform=custom_preprocess)

    # Generate text labels
    categories = dataset.classes
    dataset.classes = [f"a photo of {category} brain" for category in categories]

    labels_to_texts = {idx: f"a photo of {category} brain" for idx, category in enumerate(categories)}
    # Create DataLoader
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True, num_workers=4)
    return dataloader, clip_model, labels_to_texts


def contrastive_loss(images_features, texts_features, temperature=0.07):
    # Normalize features
    images_features = F.normalize(images_features, dim=1)
    texts_features = F.normalize(texts_features, dim=1)

    # Compute similarity matrix
    logits = torch.matmul(images_features, texts_features.t()) / temperature

    # Labels for contrastive loss
    labels = torch.arange(logits.size(0)).long().to(logits.device)

    # Contrastive loss
    loss = F.cross_entropy(logits, labels) + F.cross_entropy(logits.t(), labels)
    return loss/2


def train(model, train_loader, epochs=20, learning_rate=1e-4, decay_factor=0.8, step_size=5):
    device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
    model = model.to(device)
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)

    # Set up learning rate scheduler with StepLR
    scheduler = StepLR(optimizer, step_size=step_size, gamma=decay_factor)

    # Open a file to save training losses
    with open('train_loss.txt', 'w') as loss_file:
        for epoch in range(epochs):
            model.train()
            epoch_loss = 0

            for images, labels in tqdm(train_loader, desc=f"Epoch {epoch + 1}/{epochs}"):
                images, labels = images.to(model.device), labels.to(model.device)

                # Forward pass
                images_features, texts_features,_ = model(images, labels)

                # Compute contrastive loss
                loss = contrastive_loss(images_features, texts_features)

                # Backward pass and optimization
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

                epoch_loss += loss.item()

            # Update the learning rate using the scheduler
            scheduler.step()

            avg_loss = epoch_loss / len(train_loader)
            print(f"Epoch {epoch + 1}/{epochs}, Loss: {avg_loss:.4f}, LR: {optimizer.param_groups[0]['lr']:.6f}")

            # Save the loss for this epoch
            loss_file.write(f"{avg_loss:.4f} ")  # Each epoch's loss on the same line
        # 定义模型保存路径
        model_dir = './models/'
        model_path = os.path.join(model_dir, 'CTL_RN50.pth')

        # 检查目录是否存在，如果不存在则创建
        if not os.path.exists(model_dir):
            os.makedirs(model_dir)

        # After training, save the model
        torch.save(model.state_dict(), model_path)
        print("Model saved as ",model_path)



if __name__ == "__main__":
    train_dataloader, clip_model, labels_to_texts = getDataLoader_clip_model()
    print(labels_to_texts)
    device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")

    model = PromptLearningModel(clip_model,labels_to_texts).to(device)

    train(model,train_dataloader)
