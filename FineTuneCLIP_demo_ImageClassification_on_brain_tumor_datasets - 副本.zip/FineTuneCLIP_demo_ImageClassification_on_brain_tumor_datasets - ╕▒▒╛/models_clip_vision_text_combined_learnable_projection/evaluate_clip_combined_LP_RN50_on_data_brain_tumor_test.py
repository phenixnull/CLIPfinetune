from train_ClipCombinedLearnableProjection_based_RN50 import ClipCombinedLearnableProjection_based_RN50
import torch
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from torch.utils.data import DataLoader
from torchvision import datasets
from tqdm import tqdm
from CLIP_PROJECT.clip import clip

def bidirectional_loss(img_proj, text_proj):
    # 归一化投影
    img_proj = img_proj / img_proj.norm(dim=-1, keepdim=True)
    text_proj = text_proj / text_proj.norm(dim=-1, keepdim=True)

    # 计算对比损失
    logits_per_image = img_proj @ text_proj.T
    logits_per_text = text_proj @ img_proj.T

    return logits_per_image, logits_per_text


def evaluate_combined_model(test_data_dir, model_path, batch_size=32):
    device = "cuda" if torch.cuda.is_available() else "cpu"

    # 加载CLIP模型
    clip_model, preprocess = clip.load("RN50", device=device)

    # 创建模型实例
    combined_model = ClipCombinedLearnableProjection_based_RN50(
        clip_model=clip_model,
        projection_dim=256,  # Projection dimension 需要和训练时的一致
        out_dim=64,          # 输出维度也需要与训练时一致
        device=device
    ).to(device)

    # 加载训练好的模型权重
    combined_model.load_state_dict(torch.load(model_path))

    combined_model.eval()

    # 加载测试数据集并定义数据加载器
    test_dataset = datasets.ImageFolder(test_data_dir, transform=preprocess)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=4)

    all_preds = []
    all_labels = []

    with torch.no_grad():
        for images, labels in tqdm(test_loader, desc="Evaluating"):
            images = images.to(device)
            text_tokens = clip.tokenize([f"a photo of {test_dataset.classes[label]}" for label in labels]).to(device)

            # 提取图像和文本特征
            img_proj, text_proj = combined_model(images, text_tokens)

            # 计算相似度（使用zero-shot方法）
            logits_per_image, logits_per_text = bidirectional_loss(img_proj, text_proj)

            # 获取预测类别
            preds = logits_per_image.argmax(dim=-1).cpu().numpy()
            all_preds.extend(preds)
            all_labels.extend(labels.cpu().numpy())

    # 计算分类评价指标
    accuracy = accuracy_score(all_labels, all_preds)
    precision = precision_score(all_labels, all_preds, average='weighted')
    recall = recall_score(all_labels, all_preds, average='weighted')
    f1 = f1_score(all_labels, all_preds, average='weighted')

    # 输出并保存结果
    save_dict = {
        'model':'LP_RN50',
        'Accuracy': accuracy,
        'Precision': precision,
        'Recall': recall,
        'F1-score': f1
    }



    with open("metrics_combined_model.txt", "w") as f:
        for metric, value in save_dict.items():
            f.write(f"{metric} ")
        f.write('\n')
        for metric, value in save_dict.items():
            f.write(f"{value} ")


if __name__ == "__main__":
    test_data_dir = "../dataset/data_brain_tumor_test"
    model_path = "./models/combined_model_RN50.pth"
    evaluate_combined_model(test_data_dir, model_path)
