import matplotlib.pyplot as plt

# 从文件加载Loss值
losses = "3.3162 3.0459 2.9868 2.9669 2.9483 2.9432 2.9274 2.9220 2.9142 2.9211 2.9081 2.9099 2.8993 2.9005 2.8944".split()
losses = [float(loss) for loss in losses]
# 创建x轴数据（Epoch）
epochs = list(range(1, len(losses) + 1))

# 绘制Loss曲线
plt.plot(epochs, losses, marker='o', color='r', label='Loss')

# 添加图表标题和标签
plt.title('Training Loss per Epoch for ClipCombinedLearnableProjection with RN50')
plt.xlabel('Epoch')
plt.ylabel('Loss')

# 显示网格
plt.grid(True)

# 显示图例
plt.legend()

# 保存图形为png文件
plt.savefig('plot_loss_15epochs_ClipCombinedLP_RN50.png')

# 显示图形
plt.show()
