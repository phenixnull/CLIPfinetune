import os
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torchvision import datasets
from tqdm import tqdm
from CLIP_PROJECT.clip import clip


class ClipCombinedLearnableProjection_based_RN50(nn.Module):
    def __init__(self, clip_model, projection_dim: int = 256, out_dim: int = 256, device: str = "cuda"):
        super(ClipCombinedLearnableProjection_based_RN50, self).__init__()

        # 保存CLIP模型
        self.clip_model = clip_model
        self.clip_model.eval()
        for param in self.clip_model.parameters():
            param.requires_grad = False

        # 定义投影层
        visual_output_dim = 1024  # 根据RN50的输出特征维度
        text_input_dim = 1024  # 根据RN50的文本输出维度

        # 使用正确的输入输出维度来定义投影层
        self.img_projection = nn.Sequential(
            nn.Linear(visual_output_dim, projection_dim).to(device),
            nn.GELU().to(device),
            nn.Linear(projection_dim, out_dim).to(device),
        )

        self.text_projection = nn.Sequential(
            nn.Linear(text_input_dim, projection_dim).to(device),
            nn.GELU().to(device),
            nn.Linear(projection_dim, out_dim).to(device)
        )

    def forward(self, images, text_tokens):
        # 使用冻结的编码器对图像和文本进行编码，并转换为浮动类型
        img_features = self.clip_model.encode_image(images).float()  # 直接调用encode_image
        text_features = self.clip_model.encode_text(text_tokens).float()  # 直接调用encode_text

        # 应用投影层
        img_features = self.img_projection(img_features)
        text_features = self.text_projection(text_features)

        return img_features, text_features

    def image_encoder(self, images):
        """ 提取图像特征 """
        with torch.no_grad():
            img_features = self.clip_model.encode_image(images).float()
            img_features = self.img_projection(img_features)
        return img_features

    def text_encoder(self, text_tokens):
        """ 提取文本特征 """
        with torch.no_grad():
            text_features = self.clip_model.encode_text(text_tokens).float()
            text_features = self.text_projection(text_features)
        return text_features


def bidirectional_loss(img_proj, text_proj):
    # 归一化投影
    img_proj = img_proj / img_proj.norm(dim=-1, keepdim=True)
    text_proj = text_proj / text_proj.norm(dim=-1, keepdim=True)

    # 计算对比损失
    logits_per_image = img_proj @ text_proj.T
    logits_per_text = text_proj @ img_proj.T

    labels = torch.arange(len(img_proj)).to(img_proj.device)
    loss_img = nn.CrossEntropyLoss()(logits_per_image, labels)
    loss_text = nn.CrossEntropyLoss()(logits_per_text, labels)

    return (loss_img + loss_text) / 2


def train_combined_model(clip_model_path, train_data_dir, save_dir, projection_dim=256, lr=1e-4, epochs=10,
                         batch_size=32):
    device = "cuda" if torch.cuda.is_available() else "cpu"

    # 加载CLIP模型（不转为ScriptModule）
    clip_model, preprocess = clip.load("RN50", device=device)  # 使用CLIP的预处理方法

    # 初始化基于RN50的模型
    combined_model = ClipCombinedLearnableProjection_based_RN50(
        clip_model=clip_model,  # 传递已加载的CLIP模型
        projection_dim=projection_dim,
        device=device
    )

    # 定义优化器
    optimizer = torch.optim.Adam(combined_model.parameters(), lr=lr)

    # 加载数据集并定义数据加载器
    train_dataset = datasets.ImageFolder(train_data_dir, transform=preprocess)
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=4)

    # 保存损失文件
    loss_file_path = os.path.join(save_dir, "Loss_ClipCombinedLearnableProjection_15epochs_RN50.txt")

    # 训练过程
    combined_model.train()
    with open(loss_file_path, 'w') as loss_file:
        for epoch in range(epochs):
            epoch_loss = 0.0
            for images, labels in tqdm(train_loader, desc=f"Epoch {epoch + 1}/{epochs}"):
                # 准备文本token
                text_tokens = clip.tokenize([f"a photo of {train_dataset.classes[label]}" for label in labels]).to(
                    device)
                images = images.to(device)

                # 正向传播
                img_proj, text_proj = combined_model(images, text_tokens)

                # 计算损失
                loss = bidirectional_loss(img_proj, text_proj)

                # 反向传播与优化
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

                epoch_loss += loss.item()

            # 保存每个epoch的损失
            epoch_avg_loss = epoch_loss / len(train_loader)
            loss_file.write(f"{epoch_avg_loss:.4f} ")  # 每个epoch损失值保留四位小数并写入文件
            print(f"Epoch [{epoch + 1}/{epochs}], Loss: {epoch_avg_loss:.4f}")

    # 保存训练好的模型
    model_save_path = os.path.join(save_dir, "combined_model_RN50.pth")
    torch.save(combined_model.state_dict(), model_save_path)  # 保存模型权重（只保存权重）

    print(f"Model saved to {model_save_path}")
    print(f"Losses saved to {loss_file_path}")


if __name__ == "__main__":
    # 定义参数
    train_data_dir = "../dataset/data_brain_tumor_train"  # 数据集路径
    save_dir = "./models"  # 模型保存路径
    projection_dim = 256
    lr = 1e-4
    epochs = 15
    batch_size = 32
    clip_model_path = "../models_clip_vision_backbones/RN50.pt"  # CLIP 模型路径

    # 开始训练
    print(f"Training model for visual backbone RN50")
    train_combined_model(
        clip_model_path=clip_model_path,
        train_data_dir=train_data_dir,
        save_dir=save_dir,
        projection_dim=projection_dim,
        lr=lr,
        epochs=epochs,
        batch_size=batch_size
    )
