from CLIP_PROJECT.clip import clip
import os
import torch
from torchvision import transforms, datasets
from torch.utils.data import DataLoader
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from PIL import Image

# 数据集路径
data_dir = "dataset/data_brain_tumor_test"

# 类别名称
class_names = ["glioma_tumor", "meningioma_tumor", "normal", "pituitary_tumor"]

# 加载 CLIP 模型
device = "cuda" if torch.cuda.is_available() else "cpu"

# 文件保存路径
metrics_file_path = "metrics_zero_shot_brain_tumors_clip_models_visionbackbone_on_brain_tumor_test.txt"

# 初始化文件
with open(metrics_file_path, "w") as file:
    file.write("model Accuracy Precision Recall F1-score\n")


# 自定义数据集
class BrainTumorDataset(torch.utils.data.Dataset):
    def __init__(self, data_dir, transform):
        self.data = []
        self.labels = []
        self.transform = transform

        for label_idx, class_name in enumerate(class_names):
            class_dir = os.path.join(data_dir, class_name)
            for img_file in os.listdir(class_dir):
                img_path = os.path.join(class_dir, img_file)
                if os.path.isfile(img_path):  # 确保是文件
                    self.data.append(img_path)
                    self.labels.append(label_idx)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        img_path = self.data[idx]
        label = self.labels[idx]
        image = Image.open(img_path).convert("RGB")
        if self.transform:
            image = self.transform(image)
        return image, label


if __name__ == '__main__':
    for model_name in clip.available_models():
        print(f"[Evaluating {model_name}...]")
        # 加载模型及对应的预处理方法
        model, preprocess = clip.load(model_name, device=device, download_root="./models_clip_vision_backbones")

        # 使用模型对应的预处理方法，确保输入尺寸与模型匹配
        transform = preprocess

        # 准备数据集和 DataLoader
        dataset = BrainTumorDataset(data_dir, transform)
        dataloader = DataLoader(dataset, batch_size=32, shuffle=False)

        # 准备分类标签的文本
        text_inputs = torch.cat([clip.tokenize(f"a photo of {c}") for c in class_names]).to(device)

        # 提取文本特征
        with torch.no_grad():
            text_features = model.encode_text(text_inputs)
            text_features /= text_features.norm(dim=-1, keepdim=True)  # 归一化

        all_preds = []
        all_labels = []

        # 遍历 DataLoader
        for idx, (images, labels) in enumerate(dataloader):
            images, labels = images.to(device), labels.to(device)

            with torch.no_grad():
                image_features = model.encode_image(images)
                image_features /= image_features.norm(dim=-1, keepdim=True)  # 归一化

                # 计算余弦相似度
                similarities = image_features @ text_features.T

                # 预测类别
                predicted_labels = similarities.argmax(dim=1).tolist()
                all_preds.extend(predicted_labels)
                all_labels.extend(labels.tolist())

            print(f"\rEvaluating Batch {idx + 1}/{len(dataloader)}", end='')

        print()
        # 计算分类指标
        accuracy = accuracy_score(all_labels, all_preds)
        precision = precision_score(all_labels, all_preds, average="weighted", zero_division=0)
        recall = recall_score(all_labels, all_preds, average="weighted", zero_division=0)
        f1 = f1_score(all_labels, all_preds, average="weighted", zero_division=0)

        # 打印结果
        print(f"Model: {model_name}")
        print(f"\tAccuracy: {accuracy:.4f}")
        print(f"\tPrecision (weighted): {precision:.4f}")
        print(f"\tRecall (weighted): {recall:.4f}")
        print(f"\tF1-score (weighted): {f1:.4f}")

        # 保存结果到文件
        with open(metrics_file_path, "a") as file:
            file.write(f"{model_name} {accuracy:.4f} {precision:.4f} {recall:.4f} {f1:.4f}\n")

    print(f"Metrics saved to {metrics_file_path}")
