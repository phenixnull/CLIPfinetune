import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# 全局字体设置
plt.rcParams['font.size'] = 14  # 设置全局字体大小

# 假设文件名为 "metrics_zero_shot_brain_tumors_clip_models_visionbackbone.txt"
file_path = "metrics_zero_shot_brain_tumors_clip_models_visionbackbone.txt"

if __name__ == "__main__":
    # 从文件读取数据
    df = pd.read_csv(file_path, sep=' ', header=0)

    # df 的列结构应为: model Accuracy Precision Recall F1-score
    models = df['model'].values
    accuracy = df['Accuracy'].values
    precision = df['Precision'].values
    recall = df['Recall'].values
    f1 = df['F1-score'].values

    # 创建画布和子图
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle('Comparison of Zero-Shot CLIP Models on Brain Tumor Classification', fontsize=20)  # 标题字体更大

    # 定义统一的x轴刻度位置
    x = np.arange(len(models))
    width = 0.6  # 柱状图的宽度

    # 定义一个函数，用于绘制子图并高亮最高值
    def plot_bars(ax, values, title, color, highlight_color):
        bars = ax.bar(x, values, width, color=color, edgecolor='black')
        ax.set_title(title, fontsize=18)  # 子图标题字体更大
        ax.set_xticks(x)
        ax.set_xticklabels(models, rotation=45, ha='right', fontsize=14)  # x轴刻度字体
        ax.tick_params(axis='y', labelsize=14)  # y轴刻度字体

        # 找到最大值及其索引
        max_idx = np.argmax(values)
        max_val = values[max_idx]
        min_val = np.min(values)

        # 高亮最大值的柱子颜色
        bars[max_idx].set_facecolor(highlight_color)

        # 设置更适合放大对比的 y 轴范围
        lower_limit = max(min_val * 0.9, 0)  # 确保下限不为负
        upper_limit = max_val + 0.05
        ax.set_ylim(lower_limit, upper_limit)

        # 在每个柱顶端标注数值（加大字体）
        for i, v in enumerate(values):
            ax.text(i, v + 0.005 * (upper_limit - lower_limit), f'{v:.3f}', ha='center', fontsize=12)

    # 绘制各子图
    plot_bars(axes[0, 0], accuracy, 'Accuracy', 'skyblue', 'blue')
    plot_bars(axes[0, 1], precision, 'Precision (Weighted)', 'salmon', 'red')
    plot_bars(axes[1, 0], recall, 'Recall (Weighted)', 'lightgreen', 'green')
    plot_bars(axes[1, 1], f1, 'F1-score (Weighted)', 'violet', 'purple')

    plt.tight_layout(rect=[0, 0, 1, 0.96])  # 调整布局，将标题与子图间距优化

    # 保存图表到文件
    plt.savefig("plot_clip_zero_shot_classification_metrics_vision_backbones.png", dpi=300)
    plt.show()
