from  CLIP_PROJECT.clip import clip

if __name__ == '__main__':
    for model_name in clip.available_models():
        print("Downloading ", model_name)
        model, preprocess = clip.load(model_name,download_root='./models_clip_vision_backbones')
        print(f"Downloading {model_name} completed!")