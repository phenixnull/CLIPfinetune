import os
import shutil
import random

# 原始数据路径
src_dir = "dataset/data_brain_tumor_256_256"

# 目标数据路径
train_dir = "dataset/data_brain_tumor_train"
test_dir = "dataset/data_brain_tumor_test"
if __name__ == '__main__':
    # 确保输出目录存在
    os.makedirs(train_dir, exist_ok=True)
    os.makedirs(test_dir, exist_ok=True)

    # 类别列表（根据实际类别调整）
    class_names = ["glioma_tumor", "meningioma_tumor", "normal", "pituitary_tumor"]

    # 设定划分比例
    train_ratio = 0.7

    for class_name in class_names:
        class_src_path = os.path.join(src_dir, class_name)
        # 创建目标文件夹
        class_train_path = os.path.join(train_dir, class_name)
        class_test_path = os.path.join(test_dir, class_name)
        os.makedirs(class_train_path, exist_ok=True)
        os.makedirs(class_test_path, exist_ok=True)

        # 获取该类别下所有图片文件列表
        all_images = [f for f in os.listdir(class_src_path) if os.path.isfile(os.path.join(class_src_path, f))]
        # 打乱顺序
        random.shuffle(all_images)

        # 根据比例计算训练集与测试集数量
        train_count = int(len(all_images) * train_ratio)
        train_files = all_images[:train_count]
        test_files = all_images[train_count:]

        # 拷贝文件到训练集文件夹
        for img_file in train_files:
            src_file = os.path.join(class_src_path, img_file)
            dst_file = os.path.join(class_train_path, img_file)
            shutil.copy2(src_file, dst_file)

        # 拷贝文件到测试集文件夹
        for img_file in test_files:
            src_file = os.path.join(class_src_path, img_file)
            dst_file = os.path.join(class_test_path, img_file)
            shutil.copy2(src_file, dst_file)

    print("Data split complete.")
