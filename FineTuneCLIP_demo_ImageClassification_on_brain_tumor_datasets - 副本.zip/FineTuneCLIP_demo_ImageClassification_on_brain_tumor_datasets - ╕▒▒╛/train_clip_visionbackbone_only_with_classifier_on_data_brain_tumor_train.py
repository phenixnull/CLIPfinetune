import os
import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import transforms, datasets
from torch.utils.data import DataLoader
from CLIP_PROJECT.clip import clip
from tqdm import tqdm


# 通用训练类
class VisionBackboneClassifierTrainer:
    def __init__(self,
                 model_name: str,
                 train_data_dir: str,
                 class_names: list,
                 save_dir: str = "models_clip_vision_only_with_classifier",
                 device: str = None,
                 batch_size: int = 32,
                 lr: float = 1e-3,
                 epochs: int = 10):

        self.model_name = model_name
        self.train_data_dir = train_data_dir
        self.class_names = class_names
        self.num_classes = len(class_names)
        self.save_dir = save_dir
        os.makedirs(self.save_dir, exist_ok=True)

        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"
        self.device = device
        self.batch_size = batch_size
        self.lr = lr
        self.epochs = epochs

        # 加载 CLIP 模型及预处理方法
        self.model, self.preprocess = clip.load(model_name, device=self.device,
                                                download_root="./models_clip_vision_backbones")

        # 构建数据加载器
        self._build_dataloader()

        # 构建模型（冻结视觉骨干，仅训练一个分类层）
        self._build_classifier()

    def _build_dataloader(self):
        transform = self.preprocess  # 使用clip自带的预处理
        dataset = datasets.ImageFolder(self.train_data_dir, transform=transform)
        self.train_loader = DataLoader(dataset, batch_size=self.batch_size, shuffle=True, num_workers=4)

    def _build_classifier(self):
        # 冻结视觉骨干参数
        for param in self.model.visual.parameters():
            param.requires_grad = False

        # 在model.visual输出的特征之后加入一个线性分类层
        visual_output_dim = self.model.visual.output_dim  # CLIP视觉模型输出的特征维度
        self.classifier = nn.Linear(visual_output_dim, self.num_classes).to(self.device)

        # CLIP 模型只负责特征提取，不修改其结构
        self.model.eval()

    def train(self):
        optimizer = optim.Adam(self.classifier.parameters(), lr=self.lr)
        criterion = nn.CrossEntropyLoss()

        for epoch in range(self.epochs):
            self.model.visual.eval()
            self.classifier.train()

            running_loss = 0.0
            correct = 0
            total = 0

            for images, labels in tqdm(self.train_loader, desc=f"Epoch {epoch + 1}/{self.epochs}"):
                images, labels = images.to(self.device), labels.to(self.device)
                optimizer.zero_grad()

                with torch.no_grad():
                    image_features = self.model.encode_image(images)
                    image_features = image_features.float()

                outputs = self.classifier(image_features)
                loss = criterion(outputs, labels)

                loss.backward()
                optimizer.step()

                running_loss += loss.item() * images.size(0)
                _, predicted = outputs.max(1)
                correct += predicted.eq(labels).sum().item()
                total += labels.size(0)

            epoch_loss = running_loss / total
            epoch_acc = correct / total
            print(f"Epoch [{epoch + 1}/{self.epochs}]: Loss={epoch_loss:.4f}, Acc={epoch_acc:.4f}")

        # 在这里对模型名称进行安全化处理
        safe_model_name = self.model_name.replace("/", "_").replace("@", "_")
        save_path = os.path.join(self.save_dir, f"{safe_model_name}_classifier.pth")
        # 保存模型结构和参数
        torch.save(self.classifier, save_path)
        print(f"Model saved to {save_path}")


if __name__ == "__main__":
    # 定义类名和数据集路径
    class_names = ["glioma_tumor", "meningioma_tumor", "normal", "pituitary_tumor"]
    train_data_dir = "dataset/data_brain_tumor_train"

    available_models = ["RN50", "RN101", "RN50x4", "RN50x16", "RN50x64", "ViT-B/32", "ViT-B/16", "ViT-L/14",
                        "ViT-L/14@336px"]

    for model_name in available_models[:]:
        print(f"Training classifier for {model_name}...")
        trainer = VisionBackboneClassifierTrainer(
            model_name=model_name,
            train_data_dir=train_data_dir,
            class_names=class_names,
            save_dir="models_clip_vision_only_with_classifier",  # 传递非空路径
            epochs=15,
            lr=1e-3,
            batch_size=32
        )
        trainer.train()
